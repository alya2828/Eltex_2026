#!/bin/bash

CONF="observer.conf"
LOG="observer.log"

while IFS= read -r task; do
    # Проверяем, есть ли процесс
    if ! pgrep -f "$task" >/dev/null; then
        nohup "./$task" >/dev/null 2>&1 &
        echo "$(date '+%Y-%m-%d %H:%M:%S') Перезапущен $task" >> "$LOG"
    fi
done < "$CONF"
