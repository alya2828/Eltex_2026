#!/bin/bash

RUN_DIR="/tmp/run"
FIFO="$RUN_DIR/cuckoo.pid"
LOG="$RUN_DIR/cuckoo.log"

mkdir -p "$RUN_DIR"
[ ! -p "$FIFO" ] && mkfifo "$FIFO"

echo "$(date '+%Y-%m-%d %H:%M:%S') Startup!" >> "$LOG"

shutdown() {
    echo "$(date '+%Y-%m-%d %H:%M:%S') Shutdown!" >> "$LOG"
    exit 0
}

trap shutdown SIGTERM

# Основной цикл
while true; do
    if read line <"$FIFO"; then
        # Ожидаем формат: NAME[PID]: how much time do I have? /tmp/response_fifo
        NAME=$(echo "$line" | awk -F'[: ]+' '{print $1}')
        PID=$(echo "$line" | awk -F'[: ]+' '{print $2}' | tr -d '[]')
        REPLY_FIFO=$(echo "$line" | awk '{print $NF}')

        # Генерируем число от 2 до 10
        N=$((RANDOM % 9 + 2))

        # Пишем в отдельный FIFO
        echo "$N" > "$REPLY_FIFO"

        # Логируем обращение
        echo "$(date '+%Y-%m-%d %H:%M:%S') $NAME[$PID] $N" >> "$LOG"
    fi
done
