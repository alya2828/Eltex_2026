#!/bin/bash

SELF_NAME=$(basename "$0")
LOG="report_${SELF_NAME%.sh}.log"

if [[ "$SELF_NAME" == "template_task.sh" ]]; then
    echo "я бригадир, сам не работаю"
    exit 1
fi

echo "$(date '+%Y-%m-%d %H:%M:%S') [$$] Скрипт запущен" >> "$LOG"

FIFO="/tmp/run/cuckoo.pid"

# создаем временный FIFO для ответа
TMPFIFO="/tmp/$$.fifo"
mkfifo "$TMPFIFO"

# отправляем запрос в cuckoo.sh
echo "$SELF_NAME[$$]: how much time do I have? $TMPFIFO" > "$FIFO"

# ждем ответа
read N < "$TMPFIFO"

# удаляем временный FIFO
rm "$TMPFIFO"

# ждем N секунд
sleep "$N"

# логируем завершение
echo "$(date '+%Y-%m-%d %H:%M:%S') [$$] Скрипт завершился, работал $N секунд." >> "$LOG"
